/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>

#include <utils.h>

#include <io.h>

#include <mm.h>

#include <mm_address.h>

#include <sched.h>

#include <p_stats.h>

#include <errno.h>

#define LECTURA 0
#define ESCRIPTURA 1

#define NUM_COLUMNS 80
#define NUM_ROWS    25


struct shm shm_buffer[10];

void * get_ebp();

int check_fd(int fd, int permissions)
{
  if (fd!=1) return -EBADF; 
  if (permissions!=ESCRIPTURA) return -EACCES; 
  return 0;
}

void user_to_system(void)
{
  update_stats(&(current()->p_stats.user_ticks), &(current()->p_stats.elapsed_total_ticks));
}

void system_to_user(void)
{
  update_stats(&(current()->p_stats.system_ticks), &(current()->p_stats.elapsed_total_ticks));
}

int sys_ni_syscall()
{
	return -ENOSYS; 
}

int sys_getpid()
{
	int *a = (int *)0x131000;
	char c = *a;
	//printk(c);
	printc_xy(22,22,c);
	int x = shm_buffer[2].refs;
	char buff[2];
	printk("\nReferences: ");
	itoa(x, buff);
	printk(buff);


	return current()->PID;
}

int global_PID=1000;

int ret_from_fork()
{
  return 0;
}

int sys_fork(void)
{
  /*
  char a = 'a';
  int* ptr = (int *)0x131000;
  *ptr = a;
  */
  struct list_head *lhcurrent = NULL;
  union task_union *uchild;
  
  /* Any free task_struct? */
  if (list_empty(&freequeue)) return -ENOMEM;

  lhcurrent=list_first(&freequeue);
  
  list_del(lhcurrent);
  
  uchild=(union task_union*)list_head_to_task_struct(lhcurrent);
  
  /* Copy the parent's task struct to child's */
  copy_data(current(), uchild, sizeof(union task_union));
  
  /* new pages dir */
  allocate_DIR((struct task_struct*)uchild);
  
  /* Allocate pages for DATA+STACK */
  int new_ph_pag, pag, i;
  page_table_entry *process_PT = get_PT(&uchild->task);
  /*for (pag=0; pag<NUM_PAG_DATA; pag++)
  {
    new_ph_pag=alloc_frame();
    if (new_ph_pag!=-1) // One page allocated
    {
      set_ss_pag(process_PT, PAG_LOG_INIT_DATA+pag, new_ph_pag);
    }
    else // No more free pages left. Deallocate everything
    {
      // Deallocate allocated pages. Up to pag.
      for (i=0; i<pag; i++)
      {
        free_frame(get_frame(process_PT, PAG_LOG_INIT_DATA+i));
        del_ss_pag(process_PT, PAG_LOG_INIT_DATA+i);
      }
      // Deallocate task_struct
      list_add_tail(lhcurrent, &freequeue);
      
      // Return error
      return -EAGAIN; 
    }
  }*/

  /* Copy parent's SYSTEM and CODE to child. */
  page_table_entry *parent_PT = get_PT(current());
  for (pag=0; pag<NUM_PAG_KERNEL; pag++)
  {
    set_ss_pag(process_PT, pag, get_frame(parent_PT, pag));
  }
  for (pag=0; pag<NUM_PAG_CODE; pag++)
  {
    set_ss_pag(process_PT, PAG_LOG_INIT_CODE+pag, get_frame(parent_PT, PAG_LOG_INIT_CODE+pag));
  }
  /* Copy parent's DATA to child. We will use TOTAL_PAGES-1 as a temp logical page to map to */
  for (pag=NUM_PAG_KERNEL+NUM_PAG_CODE; pag<NUM_PAG_KERNEL+NUM_PAG_CODE+NUM_PAG_DATA; pag++)
  {
    /* Map one child page to parent's address space. */
    set_ss_pag(process_PT, pag, get_frame(parent_PT, pag));
    process_PT[pag].bits.rw=0;
    parent_PT[pag].bits.rw=0;
    //copy_data((void*)(pag<<12), (void*)((pag+NUM_PAG_DATA)<<12), PAGE_SIZE);
    //del_ss_pag(parent_PT, pag+NUM_PAG_DATA);
  }

  for (int i = NUM_PAG_CODE + NUM_PAG_DATA * 2 + NUM_PAG_KERNEL; i < TOTAL_PAGES; ++i) {
	  void *phys_addr = get_frame(parent_PT, i);
	  for (int j = 0; j < 10; ++j) {
	  	if (shm_buffer[j].id_frame_fisic == phys_addr) {
			//printk("fork_test\n");
			set_ss_pag(process_PT, i, phys_addr);
			shm_buffer[j].refs++;
		}
	  }
  }
  /* Deny access to the child's memory space */
  set_cr3(get_DIR(current()));

  uchild->task.PID=++global_PID;
  uchild->task.state=ST_READY;

  int register_ebp;		/* frame pointer */
  /* Map Parent's ebp to child's stack */
  register_ebp = (int) get_ebp();
  register_ebp=(register_ebp - (int)current()) + (int)(uchild);

  uchild->task.register_esp=register_ebp + sizeof(DWord);

  DWord temp_ebp=*(DWord*)register_ebp;
  /* Prepare child stack for context switch */
  uchild->task.register_esp-=sizeof(DWord);
  *(DWord*)(uchild->task.register_esp)=(DWord)&ret_from_fork;
  uchild->task.register_esp-=sizeof(DWord);
  *(DWord*)(uchild->task.register_esp)=temp_ebp;

  /* Set stats to 0 */
  init_stats(&(uchild->task.p_stats));

  /* Queue child process into readyqueue */
  uchild->task.state=ST_READY;
  list_add_tail(&(uchild->task.list), &readyqueue);
  
  return uchild->task.PID;
}

#define TAM_BUFFER 512

int sys_write(int fd, char *buffer, int nbytes) {
char localbuffer [TAM_BUFFER];
int bytes_left;
int ret;

	if ((ret = check_fd(fd, ESCRIPTURA)))
		return ret;
	if (nbytes < 0)
		return -EINVAL;
	if (!access_ok(VERIFY_READ, buffer, nbytes))
		return -EFAULT;
	
	bytes_left = nbytes;
	while (bytes_left > TAM_BUFFER) {
		copy_from_user(buffer, localbuffer, TAM_BUFFER);
		ret = sys_write_console(localbuffer, TAM_BUFFER);
		bytes_left-=ret;
		buffer+=ret;
	}
	if (bytes_left > 0) {
		copy_from_user(buffer, localbuffer,bytes_left);
		ret = sys_write_console(localbuffer, bytes_left);
		bytes_left-=ret;
	}
	return (nbytes-bytes_left);
}


extern int zeos_ticks;

int sys_gettime()
{
  return zeos_ticks;
}

void sys_exit()
{  
  int i;

  page_table_entry *process_PT = get_PT(current());

  for (int i = NUM_PAG_CODE + NUM_PAG_DATA * 2 + USER_FIRST_PAGE; i < TOTAL_PAGES; ++i) {
	  void *phys_addr = get_frame(process_PT, i);
	  for (int j = 0; j < 10; ++j) {
	  	if (shm_buffer[j].id_frame_fisic == phys_addr) shm_buffer[j].refs--;
		if (shm_buffer[j].refs == 0) {
			sys_shmrm(j);
			sys_shmdt(i);
		}
	  }
  }

  // Deallocate all the propietary physical pages
  for (i=0; i<NUM_PAG_DATA; i++)
  {
    free_frame(get_frame(process_PT, PAG_LOG_INIT_DATA+i));
    del_ss_pag(process_PT, PAG_LOG_INIT_DATA+i);
  }
  
  /* Free task_struct */
  list_add_tail(&(current()->list), &freequeue);
  
  current()->PID=-1;
  
  /* Restarts execution of the next process */
  sched_next_rr();
}

/* System call to force a task switch */
int sys_yield()
{
  force_task_switch();
  return 0;
}

extern int remaining_quantum;

int sys_get_stats(int pid, struct stats *st)
{
  int i;
  
  if (!access_ok(VERIFY_WRITE, st, sizeof(struct stats))) return -EFAULT; 
  
  if (pid<0) return -EINVAL;
  for (i=0; i<NR_TASKS; i++)
  {
    if (task[i].task.PID==pid)
    {
      task[i].task.p_stats.remaining_ticks=remaining_quantum;
      copy_to_user(&(task[i].task.p_stats), st, sizeof(struct stats));
      return 0;
    }
  }
  return -ESRCH; /*ESRCH */
}


extern char keyboard_cyclic_buffer[32];
extern int write_cyclic_buffer_it;
extern int read_cyclic_buffer_it;
extern int cyclic_buffer_is_full;

int sys_read(char *b, int maxchars)
{
	if (maxchars < 0) return -EINVAL;
  	if (!access_ok(VERIFY_WRITE, b, maxchars)) return -EFAULT; 

	int b_it = 0;
	for (b_it = 0; b_it < maxchars; b_it++)
	{
		if (write_cyclic_buffer_it == (read_cyclic_buffer_it + b_it) % sizeof(keyboard_cyclic_buffer)) {
		       	break;
		}
		char tmp_buffer = keyboard_cyclic_buffer[(read_cyclic_buffer_it + b_it) % sizeof(keyboard_cyclic_buffer)];
		copy_to_user(&tmp_buffer, b + b_it, sizeof(char));
	}	
  	read_cyclic_buffer_it = (read_cyclic_buffer_it + b_it) % sizeof(keyboard_cyclic_buffer);
	if (b_it != 0) cyclic_buffer_is_full = 0;
	return b_it;
}

int writing_color = 0x1e;
int sys_set_color(int fg, int bg) {
    /* Byte de color:
     *          0000 black              1000 dark gray
     *          0001 blue               1001 light blue
     *          0010 green              1010 light green
     *          0011 cyan               1011 light cyan
     *          0100 red                1100 light red
     *          0101 magenta            1101 light magenta
     *          0110 brown              1110 yellow
     *          0111 light gray         1111 white
     *          0-3 foreground color
     *          4-6 background color
     *          7   blinking/static (1/0)
     *          */
	if (bg < 0 || bg > 7) return -EINVAL;
	if (fg < 0 || bg > 15) return -EINVAL;

	writing_color = (bg << 4) | fg;
	return 0;
}

Byte x, y = 19;
char buff[32];
int sys_gotoxy(int next_x, int next_y) {
	if (next_x < 0 || next_x > NUM_COLUMNS) {
		return -EINVAL;
	}
	if (next_y < 0 || next_y > NUM_ROWS) {
		return -EINVAL;
	}
	x = (Byte) next_x;
	y = (Byte) next_y;
	return 0;
}

void* sys_shmat(int id, void *addr) {
	if (id < 0 || id > 9) return (void*) -EINVAL;
	int first_available_page = 2 * NUM_PAG_DATA + PAG_LOG_INIT_DATA;
	void *first_available_page_address = first_available_page * PAGE_SIZE;
	//void *first_available_page_address = first_available_page << 12;
	if (addr == NULL || addr < first_available_page_address) addr = first_available_page_address;
	if (((unsigned long) addr & 0x00000FFF) == 1) return (void*) -EINVAL;
	
	int found = 0;
	while (first_available_page < TOTAL_PAGES) {
		if (!get_frame(get_PT(current()), (int) addr >> 12)) {
			found = 1;
			break;
		}
		addr += PAGE_SIZE;
		first_available_page++;
	} 
	if (!found) return (void*) -ENOSPC;
	set_ss_pag(get_PT(current()), (int) addr >> 12, shm_buffer[id].id_frame_fisic);
	shm_buffer[id].refs++;	
	return addr;
}

int sys_shmdt(void *addr) {
	if (addr == NULL) return -EINVAL;
  //if(!access_ok(VERIFY_WRITE, addr, PAGE_SIZE)) return -EINVAL;
  //addr = (int) addr & 0x00000FFF; //alineamos direccion
  int id = -1;

  for(int i = 0; i < 10; i++) {
    if(shm_buffer[i].id_frame_fisic == get_frame(get_PT(current()), (int) addr >> 12)) id = i;
  }
  
  if(id < 0) return -EINVAL; //addr no tiene mapeada ningun frame de memoria compartida
  
  //Decremantamos #referencias
  shm_buffer[id].refs--;

  //Set frame to 0
  unsigned long *address = addr;
  if(shm_buffer[id].refs == 0 && shm_buffer[id].delete == 1) {
    shm_buffer[id].delete = 0;

    for(int i = 0; i < 1024; i++) {
      address[i] = 0;
    }
  }
  
  //Eliminamos el mapeo i flush de la TLB
  del_ss_pag(get_PT(current()), (int) addr >> 12); 
  set_cr3(get_DIR(current()));
  return 0;
}

int sys_shmrm(int id) {
  if (id < 0 || id > 9) return -EINVAL;
  shm_buffer[id].delete = 1;
  return 0;
}
