#include <libc.h>

char buff[24];

int pid;
char reading_buffer[32];
char tmp[32];

/* Calculate FPS

  int frames = 0;
  float fps() {
    return frames/(gettime()/18);
  }

*/

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */
  
  /*
  References: 1
  *ADDR: 5
  References: 0

  */

  //*ADDR: 5
  int *addr1 = shmat(2, 0x131000);
  *addr1 = 5;
  itoa(*addr1, tmp);
  write(1, "\n*ADDR: ", 8);
  write(1, tmp, sizeof(tmp));

  shmdt(0x131000);

  //*ADDR: 5
  int *addr2 = shmat(2, 0x131000);
  itoa(*addr2, tmp);
  write(1, "\n*ADDR: ", 8);
  write(1, tmp, sizeof(tmp));

  //*ADDR: 0
  shmrm(2);
  shmdt(0x131000);

  int *addr3 = shmat(2, 0x131000);
  itoa(*addr3, tmp);
  write(1, "\n*ADDR: ", 8);
  write(1, tmp, sizeof(tmp));

  write(1, "\nM6 DONE", 8);

  set_color(15,0);
  //gotoxy(0, 0);
  //int a = 2;
  while(1) {
  	/*int n = read (reading_buffer, 32);
	itoa(n, tmp);
	if(n > 0) {
		//write(1, tmp, n);
		write(1, reading_buffer, n);
     	}*/
  }
}
