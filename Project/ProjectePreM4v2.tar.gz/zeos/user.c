#include <libc.h>

char buff[24];

int pid;
char reading_buffer[32];
char tmp[32];

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */
  
  int *addr1 = shmat(2, 0x0);

  *addr1 = 5;

  int pid = fork();
  
  if (pid == 0) {
  	int *addr2 = shmat(2, 0x0);
	*addr2 = 1;
  }
  itoa(*addr1, tmp);
  write(1, tmp, sizeof(tmp));

  set_color(15,0);
  //gotoxy(0, 0);
  //int a = 2;
  while(1) {
  	/*int n = read (reading_buffer, 32);
	itoa(n, tmp);
	if(n > 0) {
		//write(1, tmp, n);
		write(1, reading_buffer, n);
     	}*/
  }
}
