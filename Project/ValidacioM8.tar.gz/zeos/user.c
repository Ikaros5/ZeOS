#include <libc.h>
char key_pressed[32];
char tmp[32];
int frames = 1;
int existeixApple = 0;
int game_finished = 0;
int snake_size = 1;
int posApplex = 0;
int posAppley = 0;
int dir = 0;

int max_length = 100;
int posx[100];
int posy[100];

float fps() {
    return frames/(gettime());
}

void spawn_apple() {
	if(!existeixApple) {
		existeixApple = 1;
		posApplex = gettime() % 80;
		posAppley = gettime() % 25;
		gotoxy(posApplex, posAppley);
		set_color(4,4);
		write(1, " ", 1);
	}
}

void update_historial() {
	
	for(int i = max_length-2; i >= 0; i--) {
		posx[i+1] = posx[i];
		posy[i+1] = posy[i];
	}
	
	//1 top, 2 right, 3 bottom, 4 left
	if(dir == 1) posy[0]--;
	else if(dir == 2) posx[0]++;
	else if(dir == 3) posy[0]++;
	else if(dir == 4) posx[0]--;
	
	//borrar cola
	gotoxy(posx[snake_size+1], posy[snake_size+1]);
	set_color(0,0);
	write(1, " ", 1);

	//pintar cabeza
	gotoxy(posx[0], posy[0]);
	set_color(2,2);
	write(1, " ", 1);
}

void eat_apple() {
	if(posx[0] == posApplex && posy[0] == posAppley) {
		snake_size += 1;
		existeixApple = 0;
	}
}

void check_colisions() {
	if(dir == 1 && posy[0] < 3) game_finished = 2; 
	else if(dir == 2 && posx[0]+1 > 80) game_finished = 2;
	else if(dir == 3 && posy[0]+1 > 25) game_finished = 2;
	else if(dir == 4 && posx[0] < 0) game_finished = 2;
	
	//Colision cola
	for(int i = 1; i < snake_size; i++) {
		if(posx[0] == posx[i] && posy[0] == posy[i]) game_finished = 2;
	}
}

void init_snake() {
	for(int i = 0; i < max_length; i++) {
		posx[i] = 40;
		posy[i] = 12;
	}
	gotoxy(40,12);
	set_color(2,2);
	write(1, " ", 1);
}

void update_stats() {
	char buffer[5] = " ";
	set_color(6,6);
	for(int i = 0; i < 80; i++) {
		for(int j = 0; j < 3; j++) {
			gotoxy(i,j);
			write(1, " ", 1);
		}
	}
	set_color(0,6);
	//print score
	gotoxy(3,1);
	write(1, "Score: ", 7);
	itoa(snake_size, buffer);
	write(1, buffer, 2);

	//print fps
	gotoxy(20,1);
	write(1, "FPS: ", 5);
	itoa(fps(), buffer);
	write(1, buffer, 5);
}

void start_game() {
	while(gettime() % 100 != 0) {}
	game_finished = 0;
	existeixApple = 0;
	snake_size = 1;
	dir = 0;
	clear_screen(0);
	init_snake();
	spawn_apple();
	update_stats();
}

void clear_screen(int color) {
	for(int i = 0; i < 80; i++) {
		for(int j = 0; j < 25; j++) {
			gotoxy(i,j);
			set_color(color, color);
			write(1, " ", 1);
		}
	}
}

int __attribute__ ((__section__(".text.main")))
	main(void) {
	//fg: same + dgrey, lblue, lgreen, lcyan, lred, lmagenta, yellow, white
	//bg: black, blue, green, cyan, red, magenta, brown, lgray
	start_game();
	while(1) {
		while(!game_finished) {
			while(gettime() % 150 != 0) {
				frames++;
			}
			int n = read(key_pressed, 1);
			if(n > 0) {
				if(key_pressed[0] == 'w' && dir != 3) dir = 1;
				else if(key_pressed[0] == 'd' && dir != 4) dir = 2;
				else if(key_pressed[0] == 's' && dir != 1) dir = 3;
				else if(key_pressed[0] == 'a' && dir != 2) dir = 4;

				else if(key_pressed[0] == 'b') snake_size++;
				else if(key_pressed[0] == 'n') game_finished = 1;
				else if(key_pressed[0] == 'm') game_finished = 2;
			}

			spawn_apple();
			update_stats();
			update_historial();
			eat_apple();
			check_colisions();
			if(snake_size >= max_length) game_finished = 1;
		}
		if(game_finished == 2) {
			game_finished = 3;
			clear_screen(4);
			gotoxy(35, 12);
			set_color(0,4);
			write(1, "YOU LOST", 8);
			gotoxy(30, 14);
			write(1, "Press r to restart", 18);
		}
		else if(game_finished == 1) {
			game_finished = 3;
			clear_screen(6);
			gotoxy(35, 12);
			set_color(0,6);
			write(1, "YOU WON", 7);	
			gotoxy(30, 14);
			write(1, "Press r to restart", 18);
		}
		int n = read(key_pressed, 1);
		if(key_pressed[0] == 'r') start_game();
	}
}
