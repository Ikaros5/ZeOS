/*
 * interrupt.c -
 */
#include <types.h>
#include <interrupt.h>
#include <segment.h>
#include <hardware.h>
#include <io.h>

#include <sched.h>

#include <zeos_interrupt.h>

Gate idt[IDT_ENTRIES];
Register    idtR;

char char_map[] =
{
  '\0','\0','1','2','3','4','5','6',
  '7','8','9','0','\'','�','\0','\0',
  'q','w','e','r','t','y','u','i',
  'o','p','`','+','\0','\0','a','s',
  'd','f','g','h','j','k','l','�',
  '\0','�','\0','�','z','x','c','v',
  'b','n','m',',','.','-','\0','*',
  '\0','\0','\0','\0','\0','\0','\0','\0',
  '\0','\0','\0','\0','\0','\0','\0','7',
  '8','9','-','4','5','6','+','1',
  '2','3','0','\0','\0','\0','<','\0',
  '\0','\0','\0','\0','\0','\0','\0','\0',
  '\0','\0'
};

int zeos_ticks = 0;

void clock_routine()
{
  zeos_show_clock();
  zeos_ticks ++;
  
  schedule();
}

extern Byte phys_mem[TOTAL_PAGES];
char keyboard_cyclic_buffer[32] = {0};
int write_cyclic_buffer_it = 0;
int read_cyclic_buffer_it = 0;
int cyclic_buffer_is_full = 0;

void keyboard_routine()
{
	if (!cyclic_buffer_is_full) {
  		unsigned char c = inb(0x60);
		if ((c & 0x80) != (0x80)) {
  			keyboard_cyclic_buffer[write_cyclic_buffer_it] = char_map[c&0x7f];
  			write_cyclic_buffer_it = (write_cyclic_buffer_it + 1) % sizeof(keyboard_cyclic_buffer);
			if (write_cyclic_buffer_it == read_cyclic_buffer_it) cyclic_buffer_is_full = 1;
		}
	}
}

void setInterruptHandler(int vector, void (*handler)(), int maxAccessibleFromPL)
{
  /***********************************************************************/
  /* THE INTERRUPTION GATE FLAGS:                          R1: pg. 5-11  */
  /* ***************************                                         */
  /* flags = x xx 0x110 000 ?????                                        */
  /*         |  |  |                                                     */
  /*         |  |   \ D = Size of gate: 1 = 32 bits; 0 = 16 bits         */
  /*         |   \ DPL = Num. higher PL from which it is accessible      */
  /*          \ P = Segment Present bit                                  */
  /***********************************************************************/
  Word flags = (Word)(maxAccessibleFromPL << 13);
  flags |= 0x8E00;    /* P = 1, D = 1, Type = 1110 (Interrupt Gate) */

  idt[vector].lowOffset       = lowWord((DWord)handler);
  idt[vector].segmentSelector = __KERNEL_CS;
  idt[vector].flags           = flags;
  idt[vector].highOffset      = highWord((DWord)handler);
}

void setTrapHandler(int vector, void (*handler)(), int maxAccessibleFromPL)
{
  /***********************************************************************/
  /* THE TRAP GATE FLAGS:                                  R1: pg. 5-11  */
  /* ********************                                                */
  /* flags = x xx 0x111 000 ?????                                        */
  /*         |  |  |                                                     */
  /*         |  |   \ D = Size of gate: 1 = 32 bits; 0 = 16 bits         */
  /*         |   \ DPL = Num. higher PL from which it is accessible      */
  /*          \ P = Segment Present bit                                  */
  /***********************************************************************/
  Word flags = (Word)(maxAccessibleFromPL << 13);

  //flags |= 0x8F00;    /* P = 1, D = 1, Type = 1111 (Trap Gate) */
  /* Changed to 0x8e00 to convert it to an 'interrupt gate' and so
     the system calls will be thread-safe. */
  flags |= 0x8E00;    /* P = 1, D = 1, Type = 1110 (Interrupt Gate) */

  idt[vector].lowOffset       = lowWord((DWord)handler);
  idt[vector].segmentSelector = __KERNEL_CS;
  idt[vector].flags           = flags;
  idt[vector].highOffset      = highWord((DWord)handler);
}

void clock_handler();
void keyboard_handler();
void system_call_handler();
void pf_handler();

void pagefault_routine(unsigned long error, unsigned long eip) {

  int cr2 = (int) get_cr2() >> 12;
  char buffer[32] = {0};
  //itoa(cr2, buffer);
  //printk(buffer);
  page_table_entry *PT = get_PT(current());
  if (PT[cr2].bits.rw == 0) {
	//printk("primer if\n");
	if (phys_mem[get_frame(PT, cr2)] == 1) {
		//printk("segon if\n");
		PT[cr2].bits.rw = 1;
	}
	else if (phys_mem[get_frame(PT, cr2)] > 1){
		//printk("tercer if\n");
		int logical_addr = NUM_PAG_DATA + PAG_LOG_INIT_DATA;
		//if(get_frame(PT, logical_addr) != 0) printk("So Bad..");
		int phys_page = alloc_frame();
		set_ss_pag(PT, logical_addr, phys_page);
		copy_data(cr2 << 12, logical_addr << 12, PAGE_SIZE);
		del_ss_pag(PT, cr2);
		set_ss_pag(PT, cr2, phys_page);
		del_ss_pag(PT, logical_addr);
	}
  	set_cr3(get_DIR(current()));
  }
  else {
  	char eip_buffer[16] = {0};
  	int i;
  	for (i=7; i >= 0; i--) {
		eip_buffer[i] = "0123456789abcdef"[eip % 16];
		eip >>= 4;
  	}
  	printk("\nProcess generates a PAGE FAULT exception at EIP: 0x");
  	printk(eip_buffer);
 	printk("\n");

  	char error_buffer[16];
  	itoa(error, error_buffer);
  	printk("Error Code: ");
  	printk(error_buffer);
  	printk("\n");


  	while(1) {}
  }
}

void setMSR(unsigned long msr_number, unsigned long high, unsigned long low);

void setSysenter()
{
  setMSR(0x174, 0, __KERNEL_CS);
  setMSR(0x175, 0, INITIAL_ESP);
  setMSR(0x176, 0, (unsigned long)system_call_handler);
}

void setIdt()
{
  /* Program interrups/exception service routines */
  idtR.base  = (DWord)idt;
  idtR.limit = IDT_ENTRIES * sizeof(Gate) - 1;
  
  set_handlers();

  /* ADD INITIALIZATION CODE FOR INTERRUPT VECTOR */
  setInterruptHandler(32, clock_handler, 0);
  setInterruptHandler(33, keyboard_handler, 0);
  setInterruptHandler(14, pf_handler, 0);

  setSysenter();

  set_idt_reg(&idtR);
}

