/*
 * io.c - 
 */

#include <io.h>

#include <types.h>

/**************/
/** Screen  ***/
/**************/

#define NUM_COLUMNS 80
#define NUM_ROWS    25

Byte x, y=19;

//Word *screen = (Word *)0xb8000; // -2 * #cols per pujar-ho una línia -> -0xA0

/* Read a byte from 'port' */
Byte inb (unsigned short port)
{
  Byte v;

  __asm__ __volatile__ ("inb %w1,%0":"=a" (v):"Nd" (port));
  return v;
}

void scroll_up()
{
  Word *screen = (Word *)0xb8000; 
  for (int i = 0; i < NUM_ROWS; ++i) {
    for (int j = 0; j < NUM_COLUMNS; ++j) {
      screen[(i * NUM_COLUMNS + j)] = screen[((i + 1) * NUM_COLUMNS + j)];
    }
  }
}

void printc(char c)
{
     __asm__ __volatile__ ( "movb %0, %%al; outb $0xe9" ::"a"(c)); /* Magic BOCHS debug: writes 'c' to port 0xe9 */
  /*if (y >= NUM_ROWS)
  {
    screen = (Word *)(0xb8000 - (2 * NUM_COLUMNS * (y - NUM_ROWS)));
  }*/
  if (c=='\n')
  {
    x = 0;
    if(y < 24) y = y+1;
    else scroll_up();
  }
  else
  {
    Word ch = (Word) (c & 0x00FF) | 0x0200;
    	// 0xb8000 és l'adreça per defecte del terminal buffer
	Word *screen = (Word *)0xb8000; // -2 * #cols per pujar-ho una línia -> -0xA0
	screen[(y * NUM_COLUMNS + x)] = ch;
    if (++x >= NUM_COLUMNS)
    {
      x = 0;
      if(y < 24) y = y+1;
      else scroll_up();
    }
  }
}

void printc_xy(Byte mx, Byte my, char c)
{
  Byte cx, cy;
  cx=x;
  cy=y;
  x=mx;
  y=my;
  printc(c);
  x=cx;
  y=cy;
}

void printk(char *string)
{
  int i;
  for (i = 0; string[i]; i++)
    printc(string[i]);
}

void printc_color(char c, char color)
{
     __asm__ __volatile__ ( "movb %0, %%al; outb $0xe9" ::"a"(c)); /* Magic BOCHS debug: writes 'c' to port 0xe9 */
  /*if (y >= NUM_ROWS)
  {
    screen = (Word *)(0xb8000 - (2 * NUM_COLUMNS * (y - NUM_ROWS)));
  }*/
  if (c=='\n')
  {
    x = 0;
    y=(y+1);//%NUM_ROWS;
  }
  else
  {
    /* Passa el caràcter al byte de menor pes amb una màscara (0x00ch),
     * A continuació omple el byte de major pes amb el color.
     * Byte de color:
     * 		0000 black		1000 dark gray
     * 		0001 blue		1001 light blue
     * 		0010 green		1010 light green
     * 		0011 cyan		1011 light cyan
     * 		0100 red		1100 light red
     * 		0101 magenta		1101 light magenta
     * 		0110 brown		1110 yellow
     * 		0111 light gray		1111 white
     * 		0-3 foreground color
     * 		4-6 background color
     * 		7   blinking/static (1/0)
     * 		*/
    Word ch = (Word) (c & 0x00FF) | (Word) (color << 8);
    	// 0xb8000 és l'adreça per defecte del terminal buffer
	Word *screen = (Word *)0xb8000; // -2 * #cols per pujar-ho una línia -> -0xA0
	screen[(y * NUM_COLUMNS + x)] = ch;
    if (++x >= NUM_COLUMNS)
    {
      x = 0;
      y=(y+1);//%NUM_ROWS;
    }
  }
}

void printk_color(char *string, char color)
{
  int i;
  for (i = 0; string[i]; i++)
    printc_color(string[i], color);
}
