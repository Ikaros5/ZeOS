#include <libc.h>

char buff[24];

int pid;

char *msg1 = "\nIT WORKS!!! :D\n";
char *msg2 = "\nHola1\n";
char *msg3 = "\nHola2\n";

char *msg4 = "\nIteration ";
char *msg5 = ", gettime is: ";
char *msg6 = " ticks\n";
char *msg7 = "Loop not working?\n";
char *buffer = "\0\0\0\0\0\0\0\0\0\0";

int addASM(int, int);

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */

  //int a = addASM(0x42,0x666);
  
  // Page Fault test
  //char *p = 0;
  //*p = 'x';

  write(1, msg1, strlen(msg1));			//It works
  write(1, msg2, strlen(msg2));			//Hola1
  write(1, msg3, strlen(msg3));			//Hola2
  
  /*int i = 0;
  //Iteration i, gettime is: gettime() ticks
  while(i < 3) {
  	write(1, msg4, strlen(msg4));		//Iteration
	itoa(i, buffer);
  	write(1, buffer, strlen(buffer));	//i
  	write(1, msg5, strlen(msg5));		//gettime is:	
  	itoa(gettime(), buffer); 		
  	write(1, buffer, strlen(buffer));	//gettime()
  	write(1, msg6, strlen(msg6));		//ticks		
	i = i +1;
  }*/

  write(1, msg1, strlen(msg1));			//It works
  
  while(1) { }
}
