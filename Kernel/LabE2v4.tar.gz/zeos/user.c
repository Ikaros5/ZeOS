#include <libc.h>

char buff[24];

int pid;

char *msg1 = "\n User.c started :D\n";
char *msg2 = "\nUser.c ending\n";
char *msg3 = "\nHola2\n";

char *msg4 = "\nIteration ";
char *msg5 = "Time is: ";
char *msg6 = " ticks.\n";
char *msg7 = "Loop not working?\n";
char *msg8 = "INIT PROCES WORKS FINE :)\n";
char *msg9 = "INIT PROCESS NOT WORKING !!!!!\n";
char buffer[32] = {0};

int addASM(int, int);

int __attribute__ ((__section__(".text.main")))
  main(void)
{
  /* 
  
  Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception
  __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) );

  int a = addASM(0x42,0x666);
  
  Page Fault test
  char *p = 0;
  *p = 'x';
  
  */

  if(write(1, msg1, strlen(msg1)) < 0) perror();	//User.c Started
  
  int i = 0;
  int zeos_ticks_count = gettime();
  //Gettime is gettime() ticks.
  while(i < 10) {
	if(gettime() != zeos_ticks_count) {
		zeos_ticks_count = gettime();
  		write(1, msg5, strlen(msg5));		//Time is	
  		itoa(gettime(), buffer); 		
  		write(1, buffer, strlen(buffer));	//gettime()
  		write(1, msg6, strlen(msg6));		//ticks		
		i++;
	}
  }

  if(getpid() == 1) write(1, msg8, strlen(msg8));
  else write(1, msg9, strlen(msg9));

  write(1, msg2, strlen(msg2));			//User.c ending
  
  while(1) { }
}
