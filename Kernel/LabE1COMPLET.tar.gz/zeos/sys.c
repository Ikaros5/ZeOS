/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>
#include <utils.h>
#include <io.h>
#include <mm.h>
#include <mm_address.h>
#include <sched.h>
#include <errno.h>

#define LECTURA 0
#define ESCRIPTURA 1
#define WRITE_BUFFER_SIZE 32


int check_fd(int fd, int permissions)
{
  if (fd!=1) return -9; /*EBADF*/
  if (permissions!=ESCRIPTURA) return -13; /*EACCES*/
  return 0;
}

int sys_write(int fd, void *buffer, int size) 
{
  int fd_err = check_fd(fd, ESCRIPTURA);
  if (fd_err < 0) return fd_err;
  if (buffer == NULL) return -EFAULT;
  if (size < 0) return -EINVAL;

  char write_buffer[WRITE_BUFFER_SIZE];
  int written_bytes = 0;
  int i;
  for (i = 0; i < size - WRITE_BUFFER_SIZE; i += WRITE_BUFFER_SIZE) {
    copy_from_user(buffer + i, write_buffer, WRITE_BUFFER_SIZE);
    written_bytes += sys_write_console(write_buffer, WRITE_BUFFER_SIZE);
  }

  copy_from_user(buffer + i, write_buffer, size % WRITE_BUFFER_SIZE);
  written_bytes += sys_write_console(write_buffer, size % WRITE_BUFFER_SIZE);
  return written_bytes;
}

extern int zeos_ticks;

int sys_gettime(int fd, void *buffer, int size) 
{
  return zeos_ticks;
}

int sys_ni_syscall()
{
	return -38; /*ENOSYS*/
}

int sys_getpid()
{
	return current()->PID;
}

int sys_fork()
{
  int PID=-1;

  // creates the child process
  
  return PID;
}

void sys_exit()
{  
}
