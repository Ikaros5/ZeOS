/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>
#include <utils.h>
#include <io.h>
#include <mm.h>
#include <mm_address.h>
#include <sched.h>
#include <errno.h>

#define LECTURA 0
#define ESCRIPTURA 1
#define WRITE_BUFFER_SIZE 32


int check_fd(int fd, int permissions)
{
  if (fd!=1) return -9; /*EBADF*/
  if (permissions!=ESCRIPTURA) return -13; /*EACCES*/
  return 0;
}

int sys_write(int fd, void *buffer, int size) 
{
  int fd_err = check_fd(fd, ESCRIPTURA);
  if (fd_err < 0) return fd_err;
  if (buffer == NULL) return -EFAULT;
  if (size < 0) return -EINVAL;

  char write_buffer[WRITE_BUFFER_SIZE];
  int written_bytes = 0;
  int i;
  for (i = 0; i < size - WRITE_BUFFER_SIZE; i += WRITE_BUFFER_SIZE) {
    copy_from_user(buffer + i, write_buffer, WRITE_BUFFER_SIZE);
    written_bytes += sys_write_console(write_buffer, WRITE_BUFFER_SIZE);
  }

  copy_from_user(buffer + i, write_buffer, size % WRITE_BUFFER_SIZE);
  written_bytes += sys_write_console(write_buffer, size % WRITE_BUFFER_SIZE);
  return written_bytes;
}

extern int zeos_ticks;
unsigned int pid_list[32768] = {0};

int sys_gettime(int fd, void *buffer, int size) 
{
  return zeos_ticks;
}

int sys_ni_syscall()
{
	return -38; /*ENOSYS*/
}

int sys_getpid()
{
	return current()->PID;
}

int ret_from_fork() {
  return 0;
}

static unsigned long long rand_state = 1;
unsigned int rand() {
	rand_state = (rand_state * 6364136223846793005ull + 1442695040888963407ull);
	return (unsigned int)((rand_state >> 16) & 0x7FFF);
}

int assignPID() {
	int next_PID = (int) rand();
	while (pid_list[next_PID] != 0) {
		next_PID = (next_PID + 1) % 32768;
	}
	pid_list[next_PID] = 1;
	return (int) next_PID;
}

int ebp_mask(union task_union *t) {
	return &((unsigned long *)KERNEL_ESP(t))[-0x13];
}

int sys_fork() { 
    	struct list_head *current_listhead = NULL;

  	//Get a free task struct, else error
  	if (!list_empty(&freequeue)) {
		current_listhead=list_first(&freequeue);
  		list_del(current_listhead);
	}
	else return -ENOMEM;
  	
	//Copy the parent's task union to the child
  	union task_union *child_taskunion = (union task_union*)list_head_to_task_struct(current_listhead);
  	copy_data(current(), child_taskunion, sizeof(union task_union));

  	//Initialize a new directory to store the process adress space
  	allocate_DIR((struct task_struct*) child_taskunion);

  	//Map logical pages for Data & Stack of child
  	page_table_entry * child_pagetable = get_PT(&child_taskunion->task);
  	for (int i = 0; i < NUM_PAG_DATA; i++) {
		int new_page = alloc_frame();
    		if (new_page != -1) {
      			set_ss_pag(child_pagetable, PAG_LOG_INIT_DATA+i, new_page);
    		}
    		else {
      			//NUM_PAG_DATA frames can't be allocated, we remove all the one that have already been allocated
      			for (int j = 0; j < i; j++) {
        			free_frame(get_frame(child_pagetable, PAG_LOG_INIT_DATA+j));
        			del_ss_pag(child_pagetable, PAG_LOG_INIT_DATA+i);
     			 }
      			list_add_tail(current_listhead, &freequeue);
      			
			//Not enough memory to create the child, return error
      			return -EAGAIN;
    		}
	}
	
	//All child frames are allocated already, now we copy the data from the parent to the child
  	page_table_entry *parent_pagetable = get_PT(current());
  	for (int i = 0; i < NUM_PAG_KERNEL; i++) set_ss_pag(child_pagetable, i, get_frame(parent_pagetable, i));
 	for (int i = 0; i < NUM_PAG_CODE; i++) set_ss_pag(child_pagetable, PAG_LOG_INIT_CODE+i, get_frame(parent_pagetable, PAG_LOG_INIT_CODE+i));
    	
	//Map child's physical pages to parent's logical address space, copy data and unmap.
  	for(int i = NUM_PAG_KERNEL+NUM_PAG_CODE; i < NUM_PAG_KERNEL+NUM_PAG_CODE+NUM_PAG_DATA; i++) {
    		set_ss_pag(parent_pagetable, NUM_PAG_DATA+i, get_frame(child_pagetable, i));
    		copy_data((void*)(i<<12), (void*)((NUM_PAG_DATA+i)<<12), PAGE_SIZE);
    		del_ss_pag(parent_pagetable, NUM_PAG_DATA+i);
  	}
  
	//Flush TLB
  	set_cr3(get_DIR(current()));
	
	//Initialize the fields of the task_struct that are not common to the child
	child_taskunion->task.PID=assignPID();
  	//child_taskunion->task.list=; //Hi ha que canivar el list del fill potser????
  	child_taskunion->task.KERNEL_ESP = ebp_mask(child_taskunion);
  	child_taskunion->task.state=ST_READY;
	
	//Modify stack	
  	((unsigned long *)KERNEL_ESP(child_taskunion))[-0x13] = 0;
  	((unsigned long *)KERNEL_ESP(child_taskunion))[-0x12] = &ret_from_fork;
	
  	list_add_tail(&(child_taskunion->task.list), &readyqueue);
	print_readyqueue();
	return child_taskunion->task.PID; 
}

void sys_exit()
{  
	page_table_entry *ppt = get_PT(current());
	for(int i = 0; i<NUM_PAG_DATA; i++) {
		free_frame(get_frame(ppt, i+PAG_LOG_INIT_DATA));
		del_ss_pag(ppt, i+PAG_LOG_INIT_DATA);
	}
	list_add_tail(&(current()->list), &freequeue);
	pid_list[current()->PID] = 0;
	current()->PID=-1;
	sched_next_rr();
}
