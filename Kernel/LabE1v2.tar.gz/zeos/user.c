#include <libc.h>

char buff[24];

int pid;

char *msg1 = "\nIT WORKS!!! :D\n";
char *msg2 = "\nHola1\n";
char *msg3 = "\nHola2\n";
char *msg4 = "\nHola3\n";
char *buffer[256];

int addASM(int, int);

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */

  //int a = addASM(0x42,0x666);
  
  // Page Fault test
  //char *p = 0;
  //*p = 'x';

  itoa(gettime(),buffer); 
  write(1, buffer, strlen(buffer));
  
  write(1, msg1, strlen(msg1));
  write(1, msg2, strlen(msg2));
  write(1, msg3, strlen(msg3));
  write(1, msg4, strlen(msg4));
  
  while(1) { }
}
