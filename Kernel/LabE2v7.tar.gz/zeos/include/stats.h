#ifndef STATS_H
#define STATS_H

struct stats
{
  unsigned long user_ticks;
  unsigned long system_ticks;
  unsigned long blocked_ticks;
  unsigned long ready_ticks;
  unsigned long elapsed_total_ticks;
  unsigned long total_trans;
  unsigned long remaining_ticks;
};
#endif
