#include <libc.h>

char buff[24];

int pid;

char *msg1 = "Time is: ";
char *msg2 = " ticks.\n";
char *msg3 = "\nI'm a child!!\n";
char *msg4 = "\nI'm a parent!!\n";
char buffer[32] = {0};

int addASM(int, int);
extern readyqueue;

int __attribute__ ((__section__(".text.main")))
  main(void)
{
  struct stats st;
  get_stats(0, &st);  
  int i = 0;
  int zeos_ticks_count = gettime();
  /*while(i < 4) {
	if(gettime() != zeos_ticks_count) {
		zeos_ticks_count = gettime();
  		write(1, msg1, strlen(msg1));		//Time is	
  		itoa(gettime(), buffer); 		
  		write(1, buffer, strlen(buffer));	//gettime()
  		write(1, msg2, strlen(msg2));		//ticks		
		i++;
	}
  }*/
	
  int PID1 = fork();
  
  if(PID1 == 0) write(1, msg3, strlen(msg3));		//I m a child
  else write(1, msg4, strlen(msg4));			//I m a parent
  while(1) { }
}
