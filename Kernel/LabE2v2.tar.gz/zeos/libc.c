/*
 * libc.c 
 */

#include <libc.h>

#include <types.h>

int errno;

void itoa(int a, char *b)
{
  int i, i1;
  char c;
  
  if (a==0) { b[0]='0'; b[1]=0; return ;}
  
  i=0;
  while (a>0)
  {
    b[i]=(a%10)+'0';
    a=a/10;
    i++;
  }
  
  for (i1=0; i1<i/2; i1++)
  {
    c=b[i1];
    b[i1]=b[i-i1-1];
    b[i-i1-1]=c;
  }
  b[i]=0;
}

int strlen(char *a)
{
  int i;
  
  i=0;
  
  while (a[i]!=0) i++;
  
  return i;
}

char errno_buffer[32] = {0};
void perror()
{
	write(1,"Error: ", 7);
	itoa(errno, errno_buffer);
	if (errno == 9) {
		char *err_buffer = "Bad file number\n";
		write(1, err_buffer, strlen(err_buffer));
	}
	if (errno == 13) {
		char *err_buffer = "Permission denied\n";
		write(1, err_buffer, strlen(err_buffer));
	}
	if (errno == 14) {
		char *err_buffer = "Bad address\n";
		write(1, err_buffer, strlen(err_buffer));
	}
	if (errno == 22) {
		char *err_buffer = "Invalid argument\n";
		write(1, err_buffer, strlen(err_buffer));
	}
	write(1, errno_buffer, strlen(errno_buffer)); // perror_code
	
}
