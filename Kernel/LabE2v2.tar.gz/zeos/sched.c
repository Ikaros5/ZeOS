/*
 * sched.c - initializes struct for task 0 anda task 1
 */

#include <sched.h>
#include <mm.h>
#include <io.h>

#define QUANTUM 10

struct list_head freequeue;
struct list_head readyqueue;

struct task_struct * idle_task;

union task_union task[NR_TASKS]
  __attribute__((__section__(".data.task")));

#if 1
struct task_struct *list_head_to_task_struct(struct list_head *l)
{
  //return list_entry( l, struct task_struct, list);
  return (struct task_struct*)((int)l&0xfffff000);
}
#endif

extern struct list_head blocked;


/* get_DIR - Returns the Page Directory address for task 't' */
page_table_entry * get_DIR (struct task_struct *t) 
{
	return t->dir_pages_baseAddr;
}

/* get_PT - Returns the Page Table address for task 't' */
page_table_entry * get_PT (struct task_struct *t) 
{
	return (page_table_entry *)(((unsigned int)(t->dir_pages_baseAddr->bits.pbase_addr))<<12);
}


int allocate_DIR(struct task_struct *t) 
{
	int pos;

	pos = ((int)t-(int)task)/sizeof(union task_union);

	t->dir_pages_baseAddr = (page_table_entry*) &dir_pages[pos]; 

	return 1;
}

void cpu_idle(void)
{
	__asm__ __volatile__("sti": : :"memory");

	while(1)
	{
	;
	}
}

void init_idle (void) {
	printk("\n\nInicio init_idle\n\n");

	struct list_head *l = freequeue.next;
  	//list_del(l);
  	struct task_struct *pcb_idle = list_head_to_task_struct(l);
  	union task_union *tu_idle = (union task_union*)pcb_idle;

  	pcb_idle->PID=0;
  	allocate_DIR(pcb_idle);
	idle_task=pcb_idle;
	
	//pcb->total_quantum=QUANTUM;

  	tu_idle->stack[KERNEL_STACK_SIZE-1]=(unsigned long)cpu_idle; //return
  	tu_idle->stack[KERNEL_STACK_SIZE-2]=0; //ebp
	pcb_idle->KERNEL_ESP= (unsigned long)&(tu_idle->stack[KERNEL_STACK_SIZE-2]); //stack top

	printk("\n\nFin init_idle\n\n");
}

void init_task1(void)
{
	struct list_head *l = freequeue.next;
	//list_del(l);
  	struct task_struct *pcb_task1 = list_head_to_task_struct(l);
	union task_union *tu_task1 = (union task_union*)pcb_task1;

  	pcb_task1->PID=1;
  	allocate_DIR(pcb_task1);
  	set_user_pages(pcb_task1);

	//Codi que esta al github del Hialvaro pero no se si s'ha de posar o no	
	
	//pcb_task1->total_quantum=QUANTUM;
  	//pcb->state=ST_RUN;
  	//remaining_quantum=pcb->total_quantum;
  	//init_stats(&c->p_stats);

  	tss.esp0=(DWord)&(tu_task1->stack[KERNEL_STACK_SIZE]);
  	writemsr(0x175, 0, (unsigned long)&(tu_task1->stack[KERNEL_STACK_SIZE]));

  	set_cr3(pcb_task1->dir_pages_baseAddr);
}


void init_sched()
{
	INIT_LIST_HEAD(&freequeue);
	for (int i = 0; i < NR_TASKS; i++) {
		task[i].task.PID = -1;
		list_add_tail(&(task[i].task.list), &freequeue);
	}
	//INIT_LIST_HEAD(&readyqueue);

}

void inner_task_switch(union task_union *new) {
	page_table_entry *new_DIR = get_DIR(&new->task);
	tss.esp0=(DWord)&(new->stack[KERNEL_STACK_SIZE]);
	writemsr(0x175, 0, (unsigned long)&(new->stack[KERNEL_STACK_SIZE]));
	set_cr3(new_DIR);
	switch_stack(&current()->KERNEL_ESP, &(new->task.KERNEL_ESP));
}

struct task_struct* current()
{
  int ret_value;
  
  __asm__ __volatile__(
  	"movl %%esp, %0"
	: "=g" (ret_value)
  );
  return (struct task_struct*)(ret_value&0xfffff000);
}

