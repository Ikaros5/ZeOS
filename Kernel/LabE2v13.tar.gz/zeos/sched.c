/*
 * sched.c - initializes struct for task 0 anda task 1
 */

#include <sched.h>
#include <mm.h>
#include <io.h>

#define QUANTUM 10
extern unsigned int pid_list[32768];

union task_union task[NR_TASKS]
  __attribute__((__section__(".data.task")));

#if 1
struct task_struct *list_head_to_task_struct(struct list_head *l)
{
  //return list_entry( l, struct task_struct, list);
  return (struct task_struct*)((int)l&0xfffff000);
}
#endif

extern struct list_head blocked;

/* get_DIR - Returns the Page Directory address for task 't' */
page_table_entry * get_DIR (struct task_struct *t) 
{
	return t->dir_pages_baseAddr;
}

/* get_PT - Returns the Page Table address for task 't' */
page_table_entry * get_PT (struct task_struct *t) 
{
	return (page_table_entry *)(((unsigned int)(t->dir_pages_baseAddr->bits.pbase_addr))<<12);
}


//============================== SCHEDULER ===========================//

int quantum_left = 10;

void update_sched_data_rr(void) {
	quantum_left--;
}

int needs_sched_rr(void) 
{
	char buffer[32] = {0};
	printk("Quantum left is: ");
	itoa(quantum_left, buffer);
	printk(buffer);
	printk("\n");
	if((quantum_left == 0)&&(!list_empty(&readyqueue))) {
		printk("\nNeeds scheduling\n");
		return 1;
	}
	//si la cola ready esta vacia, entonces volvemos a meter el mismo proceso (reiniciamos su quantum)
	if(quantum_left == 0) {
		printk("\nReadyqueue emtpy, reset of the current process\n");
		quantum_left = get_quantum(current());
	}
	return 0;
}

int get_quantum(struct task_struct *t) {
	return t->max_quantum;
}

void set_quantum(struct task_struct *t, int new_quantum) {
	t->max_quantum = new_quantum;
}

void update_process_state_rr(struct task_struct *t, struct list_head *dst_queue) {
  	if(t->state != ST_RUN) list_del(&(t->list));
  	if(dst_queue != NULL) {
    		list_add_tail(&(t->list), dst_queue);
    		if(dst_queue != &readyqueue) t->state=ST_BLOCKED;
    		else {
      			update_stats(&(t->p_stats.system_ticks), &(t->p_stats.elapsed_total_ticks));
      			t->state=ST_READY;
    		}
  	}
  	else t->state=ST_RUN;	
}

void sched_next_rr(void) {
	struct list_head *listhead;
  	struct task_struct *taskstruct;

 	 if (!list_empty(&readyqueue)) {
		listhead = list_first(&readyqueue);
    		list_del(listhead);
    		taskstruct = list_head_to_task_struct(listhead);
  	}
  	else taskstruct = idle_task;

  	quantum_left = get_quantum(taskstruct);
  	taskstruct->state = ST_RUN;

  	//update_stats(&(current()->p_stats.system_ticks), &(current()->p_stats.elapsed_total_ticks));
  	//update_stats(&(t->p_stats.ready_ticks), &(t->p_stats.elapsed_total_ticks));
  	//taskstruct->p_stats.total_trans++;

	char buffer[32] = {0};
	printk("Sched Next Task Switch ");
	itoa(taskstruct->PID, buffer);
	printk(buffer);
	printk("\n");
  	
	task_switch((union task_union*)taskstruct);
}

void schedule() {
	update_sched_data_rr();
	if(needs_sched_rr()) {
		update_process_state_rr(current(), &readyqueue);
		sched_next_rr();
	}
}

void update_stats(unsigned long *v, unsigned long *elapsed) {
  unsigned long ticks = get_ticks();
  *v +=ticks - *elapsed;
  *elapsed = ticks;
}

void print_readyqueue() {
	struct list_head *l;
	list_for_each(l, &readyqueue){
		struct task_struct *pcb_process = list_head_to_task_struct(l);
		char buffer[32] = {0};
		printk("- ");
		itoa(pcb_process->PID, buffer);
		printk(buffer);
		printk("\n");

	}
	printk("END OF READYQUEUE\n"); }

//===================================================================//

int allocate_DIR(struct task_struct *t) 
{
	int pos;
	pos = ((int)t-(int)task)/sizeof(union task_union);
	t->dir_pages_baseAddr = (page_table_entry*) &dir_pages[pos]; 
	return 1;
}

void cpu_idle(void)
{
	__asm__ __volatile__("sti": : :"memory");

	printk_color("ENTERING IDLE PROCESS\n", 0x5E);
	
	while(1)
	{
	//print_readyqueue();
	}
}

void init_idle (void) {

	struct list_head *l = freequeue.next;
  	list_del(l);
  	struct task_struct *pcb_idle = list_head_to_task_struct(l);
  	union task_union *tu_idle = (union task_union*)pcb_idle;

  	pcb_idle->PID=0;
	pid_list[0] = 1;
  	allocate_DIR(pcb_idle);
	pcb_idle->max_quantum=QUANTUM;
	idle_task=pcb_idle;
  	
	tu_idle->stack[KERNEL_STACK_SIZE-1]=(unsigned long)cpu_idle; //return
  	tu_idle->stack[KERNEL_STACK_SIZE-2]=0; //ebp
	pcb_idle->KERNEL_ESP= (unsigned long)&(tu_idle->stack[KERNEL_STACK_SIZE-2]); //stack top

}

void init_task1(void)
{
	struct list_head *l = freequeue.next;
	list_del(l);
  	struct task_struct *pcb_task1 = list_head_to_task_struct(l);
	union task_union *tu_task1 = (union task_union*)pcb_task1;

  	pcb_task1->PID=1;
	pid_list[1] = 1;
  	allocate_DIR(pcb_task1);
	pcb_task1->max_quantum=QUANTUM;
  	set_user_pages(pcb_task1);

  	tss.esp0=(DWord)&(tu_task1->stack[KERNEL_STACK_SIZE]);
  	writemsr(0x175, 0, (unsigned long)&(tu_task1->stack[KERNEL_STACK_SIZE]));

  	set_cr3(pcb_task1->dir_pages_baseAddr);
}


void init_sched()
{
	INIT_LIST_HEAD(&freequeue);
	for (int i = 0; i < NR_TASKS; i++) {
		task[i].task.PID = -1;
		list_add_tail(&(task[i].task.list), &freequeue);
	}
	INIT_LIST_HEAD(&readyqueue);

}

void inner_task_switch(union task_union *new) {
	page_table_entry *new_DIR = get_DIR(&new->task);
	set_cr3(new_DIR);
	tss.esp0=(DWord)&(new->stack[KERNEL_STACK_SIZE]);
	writemsr(0x175, 0x0, (unsigned long)&(new->stack[KERNEL_STACK_SIZE]));
	switch_stack(&current()->KERNEL_ESP, (new->task.KERNEL_ESP));
}

struct task_struct* current()
{
  int ret_value;
  
  __asm__ __volatile__(
  	"movl %%esp, %0"
	: "=g" (ret_value)
  );
  return (struct task_struct*)(ret_value&0xfffff000);
}

