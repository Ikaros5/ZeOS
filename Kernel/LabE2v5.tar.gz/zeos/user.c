#include <libc.h>

char buff[24];

int pid;

char *msg3 = "\nHola2\n";

char *msg4 = "\nIteration ";
char *msg5 = "Time is: ";
char *msg6 = " ticks.\n";
char *msg7 = "Loop not working?\n";
char *msg8 = "INIT PROCESS WORKS FINE :)\n";
char *msg9 = "IDLE PROCESS WORKS FINE :)\n";
char buffer[32] = {0};

int addASM(int, int);

int __attribute__ ((__section__(".text.main")))
  main(void)
{
  /* 
  
  Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception
  __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) );

  int a = addASM(0x42,0x666);
  
  Page Fault test
  char *p = 0;
  *p = 'x';
  
  */

  
  int i = 0;
  int zeos_ticks_count = gettime();
  //Gettime is gettime() ticks.
  while(i < 4) {
	if(gettime() != zeos_ticks_count) {
		zeos_ticks_count = gettime();
  		write(1, msg5, strlen(msg5));		//Time is	
  		itoa(gettime(), buffer); 		
  		write(1, buffer, strlen(buffer));	//gettime()
  		write(1, msg6, strlen(msg6));		//ticks		
		i++;
	}
  }

 //if(getpid() == 0) write(1, msg9, strlen(msg9));
 // else write(1, msg7, strlen(msg7));

  
  while(1) { }
}
